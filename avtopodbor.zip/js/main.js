$("#modal").iziModal({
	width: 750,
	padding: 80
});
$(document).on('click', '.price-button', function (event) {
    event.preventDefault();
    // $('#modal').iziModal('setZindex', 99999);
    // $('#modal').iziModal('open', { zindex: 99999 });
    $('#modal').iziModal('open');
});


$(document).on('click', '.modal-close', function (event) {
    event.preventDefault();
    // $('#modal').iziModal('setZindex', 99999);
    // $('#modal').iziModal('open', { zindex: 99999 });
    $('#modal').iziModal('close');
});

$('#burger').click(function(){
    $('.nav-menu-mobile').toggleClass('open')
})